

This package includes:

Project_Plan- The gannt chart
ProjectManagementPlan - Project management plan, with work assignments & team rankings
UserDocumentation - Instructions on how to use the app
project_highlevel_design - current prototype design
alternativehighleveldesign -  proposed solution to current prototype
A project review from the developer perspective - the project/prototype review 
Design- ALll the UML diagrams
requirements: all requirements
Username_Info
Subscription_Info
etc...



requirements.html
des
